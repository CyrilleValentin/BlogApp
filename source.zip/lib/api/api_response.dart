class ResponseApi{
  Object? data;
  Object? error;
}